## License

This SDK is licensed under the Mascotbot License. See the [LICENSE](http://license.mascot.bot) file for more details.